package csc2a.file;
/**
 * 
 * Class to handle all interactions with files
 * @author <YOUR DETAILS HERE>
 *
 */
public class GameFileHandler {
	/* TODO: Methods to handle text files */
	/* TODO: Methods to handle binary files */
}
