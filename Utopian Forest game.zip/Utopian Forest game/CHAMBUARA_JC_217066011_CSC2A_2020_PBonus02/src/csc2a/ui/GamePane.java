package csc2a.ui;


import java.io.FileInputStream;
import java.io.FileNotFoundException;

import csc2a.model.Aeroplane;
import csc2a.model.Circle;
import csc2a.model.Enemy;
import csc2a.model.GameObject;
import csc2a.model.GameObjectContainer;
import csc2a.model.Grass;
import csc2a.model.Rain;
import csc2a.model.Rectangle;
import csc2a.model.Soldier;
import csc2a.model.Sun;
import csc2a.model.TargetMarker;
import csc2a.model.Triangle;
import csc2a.util.KMBuffer;
import javafx.animation.AnimationTimer;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Reflection;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * 
 * GamePane provides a custom container to manage all game interactions
 * and host the GameCanvas
 * @author <YOUR DETAILS HERE>
 *
 */
public class GamePane extends StackPane{
	
	//Attributes
	private GameCanvas canvas; //You need the canvas so the visitor can draw on it
	private AnimationTimer gameTimer; //Used if you want to make a game that runs at 60 frames per second
	private GameObjectContainer<GameObject> gameObjects;
	private BorderPane layout = null;
	
	

	/**
	 * Default constructor
	 * @throws FileNotFoundException 
	 */
	public GamePane() throws FileNotFoundException {
		
		
		//Create the canvas to draw on
		canvas = new GameCanvas();	
		
		
		
	
		
		/*
		 * Optional (but makes your life easier)
		 * 
		 * Set up KMBuffer as the event "listener"
		 * (You can remove this line if you prefer to handle your own events)
		 * 
		 */
		setUpEventListeners();
		/*
		 * End Optional
		 */
		
		
		/* TODO: Construct your GamePane as you see fit */
		
		/* TODO: Do you game logic (See Animation Timer below) */
		gameObjects = new GameObjectContainer<>();
		
		
		Reflection ref = new Reflection();
		ref.setFraction(5);
		
		GameObject r1 = new Rectangle(65, 155,20, 80, Color.BROWN);
		GameObject r2 = new Rectangle(50, 120,10, 80, Color.BROWN);
		
		
		GameObject t1 = new Triangle(80, 70, 30, 25, 78, 120, Color.web("Green",0.25));
		GameObject t2 = new Triangle(40, 180, 60, 36, 90, 150, Color.FORESTGREEN);
		
		GameObject t3 = new Triangle(160, 200,20, 43, 90, 170, Color.FORESTGREEN);
		GameObject rd = new Rectangle(450, 40,80, 150, Color.web("Black"));
		
		
		
		GameObject c1 = new Circle(450, 100, 10, Color.WHEAT);
		gameObjects.addGameObject(rd);
		GameObject c2 = new Circle(0, 0, 35, Color.web("yellow",0.50));
		GameObject sol = new Soldier(100, 250, 150, 200, new Image(new FileInputStream(".\\src\\csc2a\\ui\\soldier.png")));
		GameObject grass = new Grass(0, 600, 350, 1200, new Image(new FileInputStream(".\\src\\csc2a\\ui\\grass.png")));
		GameObject sun = new Sun(80, 0, 60, 450, new Image(new FileInputStream(".\\src\\csc2a\\ui\\sun.png")));
		GameObject aeroplane2 = new Aeroplane(900, 10, 150, 120, new Image(new FileInputStream(".\\src\\csc2a\\ui\\aeroplane2.png")));
		GameObject enemy1 = new Enemy(100*(int)Math.random(), 100*(int)Math.random(), 150, 80, new Image(new FileInputStream(".\\src\\csc2a\\ui\\wolf2.png")));
		GameObject enemy2 = new Enemy(450, 150, 150, 80, new Image(new FileInputStream(".\\src\\csc2a\\ui\\bird.png")));
		GameObject enemy3 = new Enemy(900, 250, 150, 80, new Image(new FileInputStream(".\\src\\csc2a\\ui\\wolf.png")));
		GameObject enemy4 = new Enemy(650, 300, 150, 80, new Image(new FileInputStream(".\\src\\csc2a\\ui\\wolf3.png")));
		GameObject rain = new Rain(new Circle(2*Math.random(), 2*Math.random(), 0.09, Color.DARKBLUE), (int) canvas.getWidth());
		
		GameObject tm  = new TargetMarker(300, 250, 50,Color.BLACK, 320, 270, 10, Color.DARKRED);
		gameObjects.addGameObject(r1);
		gameObjects.addGameObject(r2);
		gameObjects.addGameObject(t1);
		gameObjects.addGameObject(t2);
		gameObjects.addGameObject(t3);
		gameObjects.addGameObject(c1);
		gameObjects.addGameObject(c2);
		gameObjects.addGameObject(sol);
		gameObjects.addGameObject(grass);
		gameObjects.addGameObject(sun);
		gameObjects.addGameObject(aeroplane2);
		gameObjects.addGameObject(rain);
		gameObjects.addGameObject(enemy1);
		gameObjects.addGameObject(enemy2);
		gameObjects.addGameObject(enemy3);
		gameObjects.addGameObject(enemy4);
		gameObjects.addGameObject(tm);
	
	
	setGameObjects(gameObjects);
	
	layout = new BorderPane();
	final Label lblLoc = new Label("***************UTOPIAN FOREST****************");
	lblLoc.setEffect(ref);
	
	DropShadow ds = new DropShadow(5, Color.RED);
	  ProgressBar pGBar = new ProgressBar();
	  pGBar.setProgress(10);
   
	
	final Label lblh = new Label("--+-- HEALTH --+--" );
	lblh.setFont(Font.font("Times New Roman", 32));
	lblh.setAlignment(Pos.BOTTOM_LEFT);
	
	lblh.setEffect(ds);
	lblLoc.setFont(Font.font("Times New Roman", 32));
	lblLoc.setStyle("-fx-background-color:blue");
	lblLoc.setAlignment(Pos.TOP_CENTER);
	
	
	final Label sLabel =new Label("--'CURRENT GAMING SCORE'-- :");
	sLabel.setEffect(ds);
	sLabel.setFont(Font.font("Times New Roman", 25));
	sLabel.setStyle("-fx-background-color:indianred");
	
	VBox vBox = new VBox(10,lblLoc,lblh,pGBar,sLabel);
	
	layout.setTop(vBox);
	
	layout.setCenter(canvas);
	
		
		/*
		 * Animation Timer 
		 * 
		 * Animation timer is only needed if you want to have a game that runs at a set frame rate (~60fps) 
		 * 
		 * You can safely remove the ApplicationTimer if you would prefer to rather implement your own 
		 * event handlers to drive your game logic (then setup your event handlers for events such as: 
		 */
		  	/*		*this.setOnKeyPressed();
		  			this.setOnKeyReleased();		
		 			this.setOnMouseMoved();		
		 			this.setOnMousePressed();
		 			this.setOnMouseReleased();
		 			this.setOnMouseEntered();
		 			this.setOnMouseExited();
		  			this.setOnMouseDragged();  
		  
		 (i.e. This object V V V ) */
		gameTimer = new AnimationTimer() {

			@Override
			public void handle(long now) {
				GamePane.this.requestFocus(); //This is important so that this class has focus (with all the event handlers) to intercept the Key and Mouse events
				
				/*
				 * Do your game logic here
				 */
				
				/* 
				 * HINT: Look up AnimationTimer
				 * See: https://docs.oracle.com/javase/8/javafx/api/javafx/animation/AnimationTimer.html
				 * it provides a handle method to perform operations 
				 * roughly 60 times per second (@ 60fps)
				 * 
				 * 
				 * Note: if you use the Event Handler Code from the KMBuffer to test for events such as:
				 * 
				 * 	Key pressed: 
				 * 		KMBuffer.isKeyPressed(KeyCode.UP); //.UP is for the Up Arrow Key
				 * 		For more see: https://docs.oracle.com/javase/8/javafx/api/javafx/scene/input/KeyCode.html */
				 System.out.println("Up arrow is pressed: " + KMBuffer.isKeyPressed(KeyCode.UP)); 
				 
				/*  Mouse in window: 
				 *  	KMBuffer.isMouseInWindow(); */
				 System.out.println("Mouse is in window: " + KMBuffer.isMouseInWindow());   
				
				/*  Mouse location: 
				 *  	KMBuffer.getMouseNodeLocation(); //OR .getMouseSceneLocation() OR .getMouseScreenLocation() (but you shouldn't really need this one) */
				 System.out.println("Mouse location relative to canvas: (" + KMBuffer.getMouseNodeLocation().getX() + "," + KMBuffer.getMouseNodeLocation().getY() + ")");   
				
				 /*  Mouse button pressed:
				 *  	KMBuffer.isLeftMousePressed();
				 *  	KMBuffer.isRightMousePressed();
				 *  	KMBuffer.isMiddleMousePressed(); */
				 System.out.println("Left mouse pressed: " + KMBuffer.isLeftMousePressed()); 
				 
				
				/* TODO: Set the GameObjects that your GameCanvas needs to draw */
				
				/* TODO: Redraw GameCanvas() */
			}
		};
		gameTimer.start();
		
		
		this.getChildren().addAll(layout);
		
		
		/* TODO: Finish setting up your GamePane */
	}
	
	public GameCanvas getCanvas() {
		return canvas;
	}

	public void setGameObjects(GameObjectContainer<GameObject> gameObjects) {
		canvas.setGameObjects(gameObjects);;
	}

	/**
	 * Method to set that the KMBuffer is responsible for handling key and mouse events
	 * (Use the KMBuffer's static methods in your GamePane to check for key and mouse events)
	 */
	private void setUpEventListeners() {
		/*--------------------------------------------------------------------
		 * 
		 * Event Handler Code
		 * 
		 * Code to set up the Keyboard and Mouse Events to be handled by the 
		 * provided KMBuffer in the util package
		 * 
		 * Note: If you want to, you can remove this code and handle events
		 * 		 yourself either in this Canvas or in your GamePane???
		 * 
		 *--------------------------------------------------------------------*/
		/*
		 * Set the event listeners to handle the key press and release events in the KMBuffer
		 */
		this.setOnKeyPressed(event    -> { KMBuffer.handleKeyPressed(event);    });
		this.setOnKeyReleased(event   -> { KMBuffer.handleKeyReleased(event);   });
		
		/*
		 * Set the event listeners to handle the mouse events in the KMBuffer
		 */
		this.setOnMouseMoved(event    -> { KMBuffer.handleMouseMoved(event);    });		
		this.setOnMousePressed(event  -> { KMBuffer.handleMousePressed(event);  });
		this.setOnMouseReleased(event -> { KMBuffer.handleMouseReleased(event); });
		this.setOnMouseEntered(event  -> { KMBuffer.handleMouseEntered(event);  });
		this.setOnMouseExited(event   -> { KMBuffer.handleMouseExited(event);   });
		//this.setOnMouseClicked(event -> {}); //You need to add an event handler to deal with this event in this Class
		
		/*--------------------------------------------------------------------
		 * 
		 * End of Event Handler Code
		 * 
		 *--------------------------------------------------------------------*/
	}
}
