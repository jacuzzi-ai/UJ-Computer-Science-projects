package csc2a.ui;

import java.util.ArrayList;

import csc2a.designpatterns.RenderGameObjectVisitor;
import csc2a.model.GameObject;
import csc2a.model.GameObjectContainer;
import csc2a.util.KMBuffer;
import javafx.scene.canvas.Canvas;
/**
 * 
 * Canvas used to render all of your GameObjects using the Visitor
 * This is the Client in the Visitor Design Pattern
 * @author  <YOUR DETAILS HERE>
 *
 */
import javafx.scene.canvas.GraphicsContext;
//import sun.misc.GC;
public class GameCanvas extends Canvas{
	
	//Attributes
	
	private GraphicsContext gc = null;
	
	RenderGameObjectVisitor visitor = new RenderGameObjectVisitor();
	/* TODO: Store all of your GameObjects (Using GameObjectContainers) here */
	 GameObjectContainer<GameObject> gameObjects = null;
	/**
	 * Default Constructor
	 */
	public GameCanvas() {
		setWidth(1024);
		setHeight(768);
		gameObjects =  new GameObjectContainer<GameObject>();
		
	}
	public void setGameObjects(GameObjectContainer<GameObject> gameObjects) {
		this.gameObjects = gameObjects;
		redrawCanvas();
	}
	
	/* TODO: Set your GameObjects and redrawCanvas() */
	
	/**
	 * Method used to redraw the canvas whenever called
	 */
	public void redrawCanvas(){
		requestFocus();
		
		gc = getGraphicsContext2D();
		visitor.setGraphicsContext(gc);
		
		for (GameObject go : gameObjects) {
			 
			 go.accept(visitor);
		}
		/* TODO: Get GraphicsContext */
		/* TODO: Set Visitor's GraphicsContext */
		/* TODO: Iterate through ALL GameObjects (Using GameObjectContainers) */
			/* TODO: Get EACH GameObject to accept() the Visitor */
	}	
}
